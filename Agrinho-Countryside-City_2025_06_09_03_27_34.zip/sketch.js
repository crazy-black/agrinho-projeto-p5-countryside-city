// =====================================
// === VARIÁVEIS GLOBAIS DO QUIZ ===
// =====================================
let img;
let uau;

function preload(){
  img = loadImage("start-agrinho-pixilart (1).png");
    uau = loadImage("pixilart-drawing (2).png");
  cr7 = loadImage("quiz-pixilart.png");
}

let questions = [];
let currentQuestionIndex = 0;
let score = 0;
let quizGameState = 'start'; // Estados: 'start', 'quiz', 'end', 'gameOver'

// Variáveis para o botão de Start do QUIZ (desenhado no canvas)
let quizStartButtonX, quizStartButtonY, quizStartButtonWidth, quizStartButtonHeight;

// Cores temáticas do QUIZ

let ruralGreenQuiz;
let urbanBlueQuiz;
let warmBrownQuiz;
let lightGreyQuiz;
let darkTextQuiz;
let correctGreenQuiz;
let wrongRedQuiz;

// =====================================
// === VARIÁVEIS GLOBAIS DO FESTINHA NA CITY ===
// =====================================
let buildings = [];
let trees = [];
let balloons = [];
let stars = [];
let people = []; // Array de pessoas, uma será o jogador
let clouds = [];
let confetti = []; // Array para guardar as partículas de confete

let isDay = true;
let transitionProgress = 0;
let toggleButton; // Botão HTML para alternar Dia/Noite do Festinha
let nextButtonFestinha; // Botão HTML de Próximo da história do Festinha
let gameStartedFestinha = false; // Controla se o Festinha na City está rodando
let gameWonFestinha = false; // Estado de Vitória do Festinha - Nova Variável!
let gameOverFestinha = false; // Declared for clarity, though not explicitly used for a unique game over screen for Festinha yet

let scoreFestinha = 0; // Pontuação do Festinha na City
let player; // O jogador do Festinha na City

// Configurações do jogo Festinha na City
const GAME_DURATION = 1000; // Aproximadamente 16 segundos por ciclo de dia (ajuste se precisar)
let gameTimer = 0;

let showInstructionsFestinha = false; // Controla a exibição das instruções do Festinha
let instructionTimerFestinha = 0;    // Temporizador para as instruções do Festinha

let showStoryFestinha = false; // Controla a tela de história do Festinha

// =====================================
// === VARIÁVEL DE CONTROLE PRINCIPAL ===
// =====================================
let isQuizActive = true; // Começa com o quiz ativo

function setup() {
    createCanvas(800, 600);

    // --- SETUP DO QUIZ ---
    // Inicializa as cores do QUIZ
  
    ruralGreenQuiz = color(100, 150, 80);
    urbanBlueQuiz = color(70, 130, 180);
    warmBrownQuiz = color(150, 100, 50);
    lightGreyQuiz = color(240);
    darkTextQuiz = color(40);
    correctGreenQuiz = color(50, 200, 50);
    wrongRedQuiz = color(255, 80, 80);

    // Define as perguntas do seu QUIZ
    questions = [
        {
            question: "Qual alimento tipicamente urbano tem suas raízes na produção rural?",
            options: ["Pizza", "Sushi", "Pão", "Hambúrguer"],
            correctAnswer: "Pão"
        },
        {
            question: "O que a cidade geralmente oferece ao campo em termos de serviços?",
            options: ["Água potável em abundância", "Acesso a mercados e tecnologia", "Mão de obra para a colheita", "Clima favorável para o plantio"],
            correctAnswer: "Acesso a mercados e tecnologia"
        },
        {
            question: "Qual dos seguintes é um exemplo de impacto ambiental que conecta o campo e a cidade?",
            options: ["O congestionamento de tráfego nas cidades", "A poluição sonora em áreas rurais", "O desmatamento para expansão urbana e agrícola", "A iluminação pública excessiva"],
            correctAnswer: "O desmatamento para expansão urbana e agrícola"
        },
        {
            question: "Como a cultura rural muitas vezes influencia a cultura urbana?",
            options: ["Através de arranha-céus e edifícios modernos", "Pela introdução de novas tecnologias de comunicação", "Com festivais, culinária e tradições populares", "Através do desenvolvimento de redes de transporte"],
            correctAnswer: "Com festivais, culinária e tradições populares"
        },
        {
            question: "O que o campo fornece de essencial para a vida na cidade?",
            options: ["Entretenimento noturno", "Grandes centros comerciais", "Alimentos, matérias-primas e recursos naturais", "Wi-Fi de alta velocidade"],
            correctAnswer: "Alimentos, matérias-primas e recursos naturais"
        }
    ];

    // Calcula a posição e tamanho do botão de Start do QUIZ (desenhado no canvas)
    quizStartButtonWidth = width * 0.3;
    quizStartButtonHeight = height * 0.1;
    quizStartButtonX = width / 2 - quizStartButtonWidth / 2;
    quizStartButtonY = height * 0.7;

    // --- SETUP DOS BOTÕES HTML DO FESTINHA NA CITY (INICIALMENTE ESCONDIDOS) ---
    // Botão de Início do Festinha na City
    
    // Botão 'Próximo' para a tela da história do Festinha
    nextButtonFestinha = createButton('Próximo');
    nextButtonFestinha.position(width / 2 - 50, height / 2 + 100);
    nextButtonFestinha.size(100, 40);
    nextButtonFestinha.mousePressed(startGameFestinha);
    nextButtonFestinha.hide(); // Esconde o botão 'Próximo' inicialmente

    // Botão de alternar Dia/Noite do Festinha (inicialmente escondido)
    toggleButton = createButton('Alternar Dia/Noite');
    toggleButton.position(10, 10);
    toggleButton.mousePressed(() => {
        isDay = !isDay;
        if (isDay) { // Reseta o timer ao mudar para dia
            gameTimer = 0;
            showInstructionsFestinha = true; // Mostra instruções ao começar o dia
            instructionTimerFestinha = 0;    // Reseta o temporizador de instruções
        }
    });
    toggleButton.hide(); // Esconde inicialmente

    // --- SETUP DOS ELEMENTOS DO FESTINHA NA CITY ---
    // Cria prédios
    for (let i = 0; i < 10; i++) {
        buildings.push(new Building(random(600, 800), random(100, 300), random(100, 150)));
    }
    for (let i = 0; i < 10; i++) {
        buildings.push(new Building(random(200, 400), random(100, 300), random(100, 150)));
    }
    for (let i = 0; i < 10; i++) {
        buildings.push(new Building(random(400, 600), random(100, 150), random(100, 150)));
    }

    // Cria árvores
    for (let i = 0; i < 7; i++) {
        trees.push(new Tree(random(50, 700), height - 150));
    }

    // Cria balões (serão criados/resetados no início do dia)
    resetBalloons();

    // Cria estrelas
    for (let i = 0; i < 50; i++) {
        stars.push(new Star(random(width), random(height / 2), random(1, 2)));
    }

    // Cria pessoas, uma será o jogador
    player = new Person(width / 2, height - 90); // Jogador começa no meio
    // Outras pessoas (NPCs)
    for (let i = 0; i < 6; i++) { // 6 NPCs + 1 jogador = 7 no total
        people.push(new Person(random(50, 700), height - 90));
    }

    // Cria nuvens
    resetClouds();
}

function draw() {
    if (isQuizActive) {
        // --- DRAW DO QUIZ ---
        background(uau); // Fundo do quiz

        // Esconde os botões HTML do Festinha enquanto o quiz está ativo
        nextButtonFestinha.hide();
        toggleButton.hide();

        if (quizGameState === 'start') {
            drawQuizStartScreen();
        } else if (quizGameState === 'quiz') {
            drawQuizScreen();
        } else if (quizGameState === 'end') {
            drawQuizEndScreen();
        } else if (quizGameState === 'gameOver') {
            drawQuizGameOverScreen();
        }
    } else {
        // --- DRAW DO FESTINHA NA CITY ---
        // NEW: Check for win state FIRST for Festinha na City
        if (gameWonFestinha) {
            drawWinScreenFestinha();
            // Ensure HTML buttons are hidden when the win screen is active
            toggleButton.hide();
            nextButtonFestinha.hide();
        } else if (!gameStartedFestinha && !showStoryFestinha) {
            // Festinha na City initial splash screen (if any, currently just background)
            // Consider adding a title or image here if needed for an initial splash
             background(0, 50, 100); // Default background if nothing specific is set
             fill(255);
             textSize(40);
             textAlign(CENTER, CENTER);
             text('BEM-VINDO À FESTINHA NA CITY!', width / 2, height / 2);
             textSize(20);
             text('Vença o Quiz para Desbloquear!', width / 2, height / 2 + 50);

        } else if (!gameStartedFestinha && showStoryFestinha) {
            // Tela da história do Festinha
            background(0, 50, 100);
            fill(255);
            textSize(32);
            textAlign(CENTER, CENTER);
            text('PARABÉNS!!', width / 2, height / 2 - 120);
            text('Você completou o quiz.', width / 2, height / 2 - 80);
            textSize(24);
            text('Agora estoure balões,', width / 2, height / 2 - 40);
            text('para poder espalhar um pouco de alegria!', width / 2, height / 2 - 0);
            nextButtonFestinha.show(); // Mostra o botão 'Próximo' do Festinha
            toggleButton.hide();
        
        } else { // This block runs when gameStartedFestinha is true and gameWonFestinha is false
            // Lógica principal do Festinha na City quando o jogo está ativo
            // Atualiza a transição Dia/Noite
            if (isDay) {
                transitionProgress = max(transitionProgress - 0.01, 0);
            } else {
                transitionProgress = min(transitionProgress + 0.01, 1);
            }

            let skyColor = lerpColor(color(135, 206, 235), color(20, 24, 82), transitionProgress);
            background(skyColor);

            // Sol ou Lua
            noStroke();
            if (isDay) {
                fill(255, 204, 0);
                ellipse(700, 100, 80, 80);
            } else {
                fill(240, 240, 255);
                ellipse(700, 100, 60, 60);
            }

            // Chão
            fill(60, 180, 75);
            rect(0, height - 50, width, 50);

            // Lógica do Jogo para Dia/Noite
            if (isDay) {
                // Modo Dia - Jogo Ativo
                for (let tree of trees) tree.show();

                // Movimento do jogador
                player.move();
                player.show();

                // Balões
                for (let i = balloons.length - 1; i >= 0; i--) {
                    balloons[i].show();
                    balloons[i].float();
                    if (balloons[i].y < -balloons[i].size) {
                        balloons.splice(i, 1); // Remove se sair da tela
                    }
                }

                // Nuvens (inimigos)
                for (let cloud of clouds) {
                    cloud.move();
                    cloud.show();

                    // Colisão Jogador-Nuvem (círculo-retângulo simples por enquanto)
                    let playerColliderX = player.x;
                    let playerColliderY = player.y + 20 - 15; // Centro aproximado do corpo do jogador
                    let playerRadius = 20; // Raio de colisão do jogador

                    // Caixa delimitadora aproximada da nuvem para colisão
                    let cloudLeft = cloud.x - 30;
                    let cloudRight = cloud.x + 30;
                    let cloudTop = cloud.y - 20;
                    let cloudBottom = cloud.y + 20;

                    if (playerColliderX + playerRadius > cloudLeft &&
                        playerColliderX - playerRadius < cloudRight &&
                        playerColliderY + playerRadius > cloudTop &&
                        playerColliderY - playerRadius < cloudBottom) {
                        // Colisão detectada!
                        scoreFestinha = max(0, scoreFestinha - 5); // Deduz pontos
                        player.x = random(width / 4, width * 3 / 4); // Move o jogador para um novo lugar
                    }
                }

                // Outras pessoas (NPCs) - mostram-se apenas durante o dia
                for (let npc of people) {
                    if (npc !== player) { // Não desenha o jogador duas vezes
                        npc.show();
                    }
                }

                // Exibe instruções durante o modo dia por um curto período
                if (showInstructionsFestinha) {
                    fill(255, 255, 0); // Cor amarela para as instruções
                    textSize(20);
                    textAlign(CENTER, TOP);
                    fill('black')
                    text('Clique nos balões para estourar', width / 2, 100);

                    instructionTimerFestinha++;
                    if (instructionTimerFestinha > 300) { // Instruções desaparecem após ~5 segundos (300 frames)
                        showInstructionsFestinha = false;
                    }
                }

                // === LÓGICA DE VITÓRIA DO FESTINHA (120 PONTOS) ===
                if (scoreFestinha >= 120) {
                    gameWonFestinha = true; // Sinaliza que o jogo foi vencido
                    gameStartedFestinha = false; // Para o jogo Festinha na City
                    toggleButton.hide(); // Esconde o botão de dia/noite
                }

                // Verifica se o tempo de dia acabou
                gameTimer++;
                if (gameTimer > GAME_DURATION) {
                    isDay = false; // Muda para noite
                    gameTimer = 0; // Reseta o timer para o próximo ciclo dia/noite
                    // Condição de game over do Festinha (se a pontuação estiver muito baixa)
                    if (scoreFestinha < -50) {
                        gameOverFestinha = true; // 
                        toggleButton.hide();
                    }
                }

                // Desenha e atualiza as partículas de confete
                for (let i = confetti.length - 1; i >= 0; i--) {
                    confetti[i].show();
                    confetti[i].update();
                    if (confetti[i].alpha <= 0) {
                        confetti.splice(i, 1); // Remove confete quando ele some
                    }
                }

            } else {
                // Modo Noite - Descanso/Observação
                for (let star of stars) {
                    star.show();
                }
                for (let building of buildings) {
                    building.show();
                    building.lightUp();
                }
                // Pessoas (NPCs e jogador) ficam escondidas durante a noite

                // Verifica se o tempo de noite acabou (se você quiser que volte ao dia)
                gameTimer++;
                if (gameTimer > GAME_DURATION / 2) { // Ciclo noturno mais curto
                    isDay = true; // Volta para o dia
                    gameTimer = 0;
                    resetBalloons(); // Reseta os balões para o novo dia
                    resetClouds(); // Reseta as nuvens para o novo dia
                    showInstructionsFestinha = true; // Mostra instruções novamente no início de um novo dia
                    instructionTimerFestinha = 0;
                }
            }

            // Exibe a pontuação do Festinha
            fill(0); // Texto preto para a pontuação
            textSize(24);
            textAlign(LEFT, TOP);
            text('Score: ' + scoreFestinha, 20, 50);

            // Garante que os botões de início e história do Festinha estejam escondidos durante o jogo ativo
            nextButtonFestinha.hide();
        }
    }
}

function mousePressed() {
    if (isQuizActive) {
        // Lógica de clique do QUIZ
        if (quizGameState === 'start') {
            // Verifica clique no botão 'Start' do Quiz
            if (mouseX > quizStartButtonX && mouseX < quizStartButtonX + quizStartButtonWidth &&
                mouseY > quizStartButtonY && mouseY < quizStartButtonY + quizStartButtonHeight) {
                quizGameState = 'quiz'; // Inicia o quiz
            }
        } else if (quizGameState === 'quiz') {
            let q = questions[currentQuestionIndex];
            let clickedOptionIndex = -1;

            let optionsStartY = height / 2;
            let optionHeight = (height - optionsStartY - 50) / q.options.length;
            let optionPadding = 10;

            for (let i = 0; i < q.options.length; i++) {
                let currentOptionY = optionsStartY + i * optionHeight + optionPadding;
                if (mouseX > width * 0.1 && mouseX < width * 0.9 &&
                    mouseY > currentOptionY && mouseY < currentOptionY + optionHeight - optionPadding) {
                    clickedOptionIndex = i;
                    break;
                }
            }

            if (clickedOptionIndex !== -1) {
                if (q.options[clickedOptionIndex] === q.correctAnswer) {
                    score++; // Incrementa score do QUIZ
                    console.log("Quiz: Correto! Score: " + score);

                    currentQuestionIndex++; // Vai para a próxima pergunta do QUIZ

                    // --- LÓGICA DE TRANSIÇÃO DO QUIZ PARA O FESTINHA NA CITY ---
                    if (currentQuestionIndex >= questions.length) { // Todas as perguntas do quiz respondidas
                        if (score === questions.length) { // Acertou TODAS as perguntas do QUIZ
                            isQuizActive = false; // Desativa o quiz
                            gameStartedFestinha = false; // Começa na tela de introdução do Festinha
                            showStoryFestinha = true; // Mostra a tela da história do Festinha
                            nextButtonFestinha.show(); // Mostra o botão Próximo da história do Festinha
                            toggleButton.hide(); // Garante que o botão de toggle esteja escondido

                            // Resetar o Festinha na City para um início limpo (se já tivesse sido jogado antes)
                            scoreFestinha = 0;
                            gameTimer = 0;
                            isDay = true;
                            player.x = width / 2;
                            resetBalloons();
                            resetClouds();
                            showInstructionsFestinha = true; // Mostra instruções na primeira vez que o Festinha for jogado
                            instructionTimerFestinha = 0;
                            gameWonFestinha = false; // Ensure Festinha win state is false on starting Festinha
                        } else {
                            // Acabou o quiz, mas não acertou todas (alguma errada)
                            quizGameState = 'end'; // Vai para a tela final normal do quiz
                        }
                    }
                } else {
                    quizGameState = 'gameOver'; // Se a resposta estiver errada, vai para Game Over do QUIZ
                    console.log("Quiz: Errado! Game Over.");
                }
            }

        } else if (quizGameState === 'end' || quizGameState === 'gameOver') {
            // Reinicia o quiz ao clicar na tela final ou de Game Over do quiz
            quizGameState = 'start';
            currentQuestionIndex = 0;
            score = 0;
        }
    } else {
        // Lógica de clique do FESTINHA NA CITY
        // Garante que o clique só funciona no Festinha se ele estiver ativo e não em game over/win
        if (gameStartedFestinha && !gameOverFestinha && isDay && !gameWonFestinha) { // Only allow clicks if game is active and not won/lost
            for (let i = balloons.length - 1; i >= 0; i--) {
                // Verifica se o clique do mouse está dentro da área do balão
                if (dist(mouseX, mouseY, balloons[i].x, balloons[i].y) < balloons[i].size / 2) {
                    // Gera confetes na posição do balão
                    for (let j = 0; j < 20; j++) { // Cria 20 partículas de confete
                        confetti.push(new Confetti(balloons[i].x, balloons[i].y));
                    }
                    balloons.splice(i, 1); // Remove o balão
                    scoreFestinha += 10; // Adiciona pontos por estourar um balão
                    showInstructionsFestinha = false; // Esconde as instruções ao clicar no balão
                }
            }
        } else if (gameWonFestinha) { // If on win screen, clicking restarts Festinha game
            startGameFestinha(); // Restart Festinha na City
            isQuizActive = false; // Make sure we stay in Festinha mode
        }
    }
}

function keyPressed() {
    if (isQuizActive) {
        // Lógica de tecla pressionada do QUIZ
        if ((quizGameState === 'gameOver' || quizGameState === 'end') && key === 'r') {
            quizGameState = 'start';
            currentQuestionIndex = 0;
            score = 0;
        }
    } else { // Festinha na City controls
        if (gameStartedFestinha && !gameOverFestinha && isDay && !gameWonFestinha) {
            if (keyCode === LEFT_ARROW || key === 'a') {
                player.vx = -3;
            } else if (keyCode === RIGHT_ARROW || key === 'd') {
                player.vx = 3;
            }
        }
    }
}

function keyReleased() {
    if (!isQuizActive) { // Apenas se o Festinha na City estiver ativo
        // Lógica de tecla solta do FESTINHA NA CITY
        if (gameStartedFestinha && !gameOverFestinha && isDay && !gameWonFestinha) {
            if (keyCode === LEFT_ARROW || key === 'a' || keyCode === RIGHT_ARROW || key === 'd') {
                player.vx = 0; // Para o movimento horizontal
            }
        }
    }
}

// =====================================
// === FUNÇÕES DE DESENHO DO QUIZ ===
// =====================================
function drawQuizStartScreen() {
    noStroke();
    background(img)
  
    textAlign(CENTER);
    fill(255); // Texto branco para contraste

    // Instruções (opcional)
    textSize(width * 0.02);
    fill('yellow'); // Mude a cor do texto para mais legibilidade nas instruções
    text("Um Quiz para Conectar Mundos!", width / 2, height * 0.45);

    // Desenha o botão de Start
    fill(correctGreenQuiz); // Cor verde para o botão
    rect(quizStartButtonX, quizStartButtonY, quizStartButtonWidth, quizStartButtonHeight, 15); // Retângulo com bordas arredondadas

    fill(255); // Cor do texto branca
    textSize(width * 0.04); // Tamanho de texto responsivo para o botão
    text("START", width / 2, quizStartButtonY + quizStartButtonHeight / 2 + (textAscent() / 2 - textDescent() / 2));
}

function drawQuizScreen() {
    let q = questions[currentQuestionIndex];
    textAlign(LEFT);
    fill(darkTextQuiz); // Cor do texto principal

    // Desenha o campo de pergunta
    let questionBoxWidth = width * 0.8;
    let questionBoxX = (width - questionBoxWidth) / 2;
    let questionBoxY = height * 0.1;
    let questionTextSize = width * 0.03; // Tamanho do texto da pergunta responsivo

    textSize(questionTextSize);
    textLeading(questionTextSize * 1.2); // Espaçamento entre linhas
    text(q.question, questionBoxX, questionBoxY, questionBoxWidth, height * 0.3); // O último parâmetro é a altura máxima da caixa de texto

    // Desenha as opções
    let optionsStartY = height / 2; // Onde as opções começam na tela
    let optionHeight = (height - optionsStartY - 50) / q.options.length; // Espaço para cada opção
    let optionPadding = 10; // Espaçamento entre as opções
    let optionTextSize = width * 0.025; // Tamanho do texto das opções responsivo

    textSize(optionTextSize);
    textLeading(optionTextSize * 1.2); // Espaçamento entre linhas das opções

    for (let i = 0; i < q.options.length; i++) {
        let currentOptionY = optionsStartY + i * optionHeight + optionPadding;
        let optionBoxX = width * 0.1; // Margem para as opções
        let optionBoxWidth = width * 0.8;

        // === LÓGICA DE HOVER APLICADA AQUI ===
        if (mouseX > optionBoxX && mouseX < optionBoxX + optionBoxWidth &&
            mouseY > currentOptionY && mouseY < currentOptionY + optionHeight - optionPadding) {
            fill(180); // Cor mais escura para o hover
        } else {
            fill(200); // Cor normal
        }
        rect(optionBoxX, currentOptionY, optionBoxWidth, optionHeight - optionPadding, 10); // Retângulo para a opção

        fill(darkTextQuiz); // Cor do texto da opção
        textAlign(LEFT);
        text(`${String.fromCharCode(65 + i)}) ${q.options[i]}`, optionBoxX + 20, currentOptionY + optionHeight / 2 + (textAscent() / 2 - textDescent() / 2));
    }

    // Exibe a pontuação do Quiz
    fill(darkTextQuiz);
    textSize(width * 0.02);
    textAlign(RIGHT);
    text(`Pontuação: ${score}/${questions.length}`, width - 50, 30);
}

function drawQuizEndScreen() {
    noStroke();
    fill(lightGreyQuiz);
    rect(0, 0, width, height);

    textAlign(CENTER);
    fill(darkTextQuiz);

    textSize(width * 0.06);
    text("Fim do Quiz!", width / 2, height * 0.3);

    textSize(width * 0.04);
    text(`Sua Pontuação Final: ${score}/${questions.length}`, width / 2, height * 0.45);

    textSize(width * 0.025);
    text("Clique em qualquer lugar para tentar novamente!", width / 2, height * 0.65);
}

function drawQuizGameOverScreen() {
    noStroke();
    background(wrongRedQuiz); // Fundo vermelho para Game Over do quiz

    textAlign(CENTER);
    fill(255); // Texto branco para contraste

    textSize(width * 0.08); // Tamanho grande para "Game Over"
    text("GAME OVER!", width / 2, height * 0.35);

    textSize(width * 0.03);
    text("Você errou a pergunta.", width / 2, height * 0.5);
    text(`Sua Pontuação: ${score} de ${questions.length}`, width / 2, height * 0.58);

    textSize(width * 0.025);
    fill(darkTextQuiz); // Mude a cor para o texto de instrução
    text("Clique em qualquer lugar para tentar novamente!", width / 2, height * 0.75);
}
// =====================================
// === FUNÇÕES E CLASSES DO FESTINHA NA CITY ===
// =====================================
// Funções para controlar as telas do Festinha na City
function showStoryScreenFestinha() {
    showStoryFestinha = true;
    nextButtonFestinha.show();
}

function startGameFestinha() {
    gameStartedFestinha = true;
    gameOverFestinha = false;
    gameWonFestinha = false; // Garante que a vitória esteja resetada
    showStoryFestinha = false;
    scoreFestinha = 0; // Reinicia a pontuação do Festinha
    gameTimer = 0; // Reinicia o timer do Festinha
    isDay = true; // Começa no modo dia
    nextButtonFestinha.hide();
    toggleButton.show(); // Mostra o botão de alternar Dia/Noite
    player.x = width / 2; // Reseta a posição do jogador
    resetBalloons(); // Reseta os balões
    resetClouds(); // Reseta as nuvens
    showInstructionsFestinha = true; // Mostra as instruções ao iniciar o Festinha
    instructionTimerFestinha = 0;
}

// Função para resetar balões
function resetBalloons() {
    balloons = []; // Limpa balões existentes
    for (let i = 0; i < 15; i++) {
        balloons.push(new Balloon(random(100, 700), random(height + 50, height + 200))); // Começa abaixo da tela
    }
}

// Função para resetar nuvens
function resetClouds() {
    clouds = [];
    for (let i = 0; i < 5; i++) {
        clouds.push(new Cloud(random(width), random(50, 150)));
    }
}

// === NOVA FUNÇÃO: Tela de Vitória do Festinha ===
function drawWinScreenFestinha() {
    background(cr7); // imagem de vitória
}

// Classe Building (Prédio)
class Building {
    constructor(x, y, w) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = random(200, 400);
    }

    show() {
        fill(150);
        rect(this.x, height - this.y, this.w, this.h);
    }

    lightUp() {
        fill(random(255), random(255), random(255), 150);
        for (let i = 0; i < 5; i++) {
            rect(this.x + 10, height - this.y + 10 + i * 50, this.w - 20, 40);
        }
    }
}

// Classe Tree (Árvore)
class Tree {
    constructor(x, y) {
        this.x = x;
        this.y = y;
    }

    show() {
        fill(139, 69, 19); // Marrom
        rect(this.x - 15, this.y, 30, 100); // Tronco
        fill(34, 139, 34); // Verde floresta
        ellipse(this.x, this.y - 50, 100, 100); // Folhagem
    }
}

// Classe Balloon (Balão)
class Balloon {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.size = random(30, 50);
        this.color = color(random(255), random(255), random(255));
    }

    show() {
        fill(this.color);
        noStroke();
        ellipse(this.x, this.y, this.size, this.size);
        stroke(0);
        line(this.x, this.y + this.size / 2, this.x, this.y + this.size + 30); // Fio do balão
    }

    float() {
        this.y -= 1; // Flutua para cima
    }
}

// Classe Star (Estrela)
class Star {
    constructor(x, y, size) {
        this.x = x;
        this.y = y;
        this.size = size;
        this.alpha = random(150, 255); // Transparência para efeito de piscar
    }

    show() {
        this.alpha += random(-10, 10);
        this.alpha = constrain(this.alpha, 100, 255);
        fill(255, 255, 255, this.alpha);
        noStroke();
        ellipse(this.x, this.y, this.size, this.size);
    }
}

// Classe Cloud (Nuvem)
class Cloud {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.speed = random(0.5, 1.5); // Nuvens com velocidades diferentes
    }

    move() {
        this.x += this.speed;
        if (this.x > width + 50) this.x = -50; // Reaparece do outro lado
    }

    show() {
        fill(255, 255, 255, 220);
        noStroke();
        ellipse(this.x, this.y, 60, 40);
        ellipse(this.x + 25, this.y + 10, 50, 30);
        ellipse(this.x - 25, this.y + 10, 50, 30);
    }
}

// Classe Person (Pessoa - Jogador e NPCs)
class Person {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.vx = 0; // Velocidade no eixo x para movimento

        this.skinColor = random([
            color(255, 224, 189), // Tons de pele variados
            color(229, 194, 152),
            color(160, 110, 70),
            color(90, 60, 40)
        ]);

        this.shirtColor = color(random(255), random(255), random(255)); // Cores de camisa aleatórias
        this.pantsColor = color(random(80, 150), random(80, 150), random(255)); // Cores de calça aleatórias

        this.hairStyle = int(random(0, 3)); // Estilo de cabelo aleatório
        this.hairColor = color(random(20, 100), random(20, 100), random(20)); // Cor de cabelo escura

        this.hasGlasses = random() < 0.3; // 30% de chance de ter óculos
        this.hasCap = random() < 0.2; // 20% de chance de ter boné
    }

    move() {
        this.x += this.vx;
        this.x = constrain(this.x, 20, width - 20);
    }

    show() {
        push();
        translate(this.x, this.y + 20);

        fill(this.skinColor);
        ellipse(0, -40, 30, 30); // Cabeça

        fill(this.hairColor);
        noStroke();
        if (this.hairStyle === 0) {
            arc(0, -50, 30, 20, PI, TWO_PI);
        } else if (this.hairStyle === 1) {
            triangle(-10, -50, 0, -60, 10, -50);
        } else {
            ellipse(0, -52, 32, 20);
        }

        if (this.hasCap) {
            fill(200, 0, 0);
            arc(0, -50, 32, 20, PI, TWO_PI);
            rect(-10, -55, 20, 5);
        }

        if (this.hasGlasses) {
            stroke(0);
            strokeWeight(1);
            noFill();
            ellipse(-5, -42, 6, 6);
            ellipse(5, -42, 6, 6);
            line(-2, -42, 2, -42);
        } else {
            fill(0);
            ellipse(-5, -42, 3, 3);
            ellipse(5, -42, 3, 3);
        }

        noFill();
        stroke(0);
        strokeWeight(1);
        arc(0, -35, 10, 5, 0, PI);

        fill(this.shirtColor);
        noStroke();
        rect(-12, -15, 24, 30, 5);

        stroke(this.skinColor);
        strokeWeight(5);
        line(-12, -10, -20, 10);
        line(12, -10, 20, 10);

        stroke(this.pantsColor);
        strokeWeight(6);
        line(-5, 15, -5, 35);
        line(5, 15, 5, 35);

        stroke(0);
        strokeWeight(8);
        line(-5, 35, -10, 35);
        line(5, 35, 10, 35);

        pop();
    }
}

// Classe Confetti
class Confetti {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.diameter = random(5, 10);
        this.color = color(random(255), random(255), random(255));
        this.xspeed = random(-3, 3);
        this.yspeed = random(-5, 0);
        this.alpha = 255;
    }

    show() {
        fill(this.color, this.alpha);
        noStroke();
        ellipse(this.x, this.y, this.diameter, this.diameter);
    }

    update() {
        this.x += this.xspeed;
        this.y += this.yspeed;
        this.yspeed += 0.1;
        this.alpha -= 3;
    }
}